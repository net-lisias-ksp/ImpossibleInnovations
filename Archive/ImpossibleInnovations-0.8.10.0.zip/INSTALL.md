# Impossible Innovations

This mod adds some late-game engines and tanks to the game. These parts are fusion-based or use advanced technologies.

Now under Lisias's management. :)


## Installation Instructions

To install, place the GameData folder inside your Kerbal Space Program folder:

* **REMOVE ANY OLD VERSIONS OF THE PRODUCT BEFORE INSTALLING**, including any other fork:
	+ Delete `<KSP_ROOT>/GameData/ImpossibleInnovations`
* Extract the package's `GameData\ImpossibleInnovations` folder into your KSP's as follows:
	+ `<PACKAGE>/GameData/ImpossibleInnovations` --> `<KSP_ROOT>/GameData/ImpossibleInnovations`
	+ `<PACKAGE>/Ships` --> `<KSP_ROOT>/Ships`
		- You can safely overwrite any old files.

The following file layout must be present after installation:

```
<KSP_ROOT>
	[GameData]
		[000_KSPAPIExtensions]
			...
		[ImpossibleInnovations]
			[Parts]
				...
			[Plugins]
				...
			[Resources]
				...
			CHANGE_LOG.md
			II-TechTree.cfg
			II-TweakScale.cfg
			ImpossibleInnovations.version
			LICENSE
			LICENSE.CC_NC-SA-4_0
			LICENSE.SKL-1_0
			NOTICE
			README.md
		[TweakScale]
			[Plugins]
				...
			[patches]
				...
			DefaultScales.cfg
			...
		000_KSPe.dll
		ModuleManager.dll
		...
[Ships]
	[SPH]
		...
		Impossible Innovations_A.craft
		...
	[VAB]
		...
		Impossible Innovations_R.craft
		...
	KSP.log
	PastDatabase.cfg
	...
```

### Dependencies

* KSPe /L [2.4.1.16 or later](https://github.com/net-lisias-ksp/KSPe/releases/) (for KSP >= 1.2.2 - yeah, anything goes) 
* [TweakScale](https://forum.kerbalspaceprogram.com/index.php?/topic/179030-*/)
	+ For existent KSP 1.3.x installations, please use [V2.3.7](https://www.curseforge.com/kerbal/ksp-mods/tweakscale/files/2490393) .
	+ For new KSP 1.3.x installations, or KSP 1.4.0 or later, use the [latest](https://www.curseforge.com/kerbal/ksp-mods/tweakscale/files).
* Module Manager
	+ MM/L is recommended, download it from [github](https://github.com/net-lisias-ksp/ModuleManager/releases).
		- For KSP 1.3.0 to 1.12.3 : download and install ModuleManager-*x.y.z.b*.zip
		- For KSP 1.2.2: download and install ModuleManager-*x.y.z.b*-**122**.zip
			- Note the "122" thingy on the end of the filename.
	+ [Forum's one](https://forum.kerbalspaceprogram.com/index.php?/topic/50533-*) is also compatible, if you are masochist enough.
